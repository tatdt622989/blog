$(function () {
  $("article").each(function () {
    if ($(this).find("header h1 a").attr("href")) {
      $(this)
        .find(".entry p>img")
        .eq(0)
        .wrap(
          `<a href="${$(this)
            .find("header h1 a")
            .attr("href")}" class="topImgWrap"></a>`
        );
    }
  });
});
